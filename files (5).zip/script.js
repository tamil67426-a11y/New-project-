/* =========================================================
   TechNova Solutions — script.js
   B.Tech IT Internship Mini Project
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {
  initNavToggle();
  initThemeToggle();
  initScrollReveal();
  initTestimonialSlider();
  initAccordion();
  initContactForm();
  initTerminalTyping();
  initHeaderShrink();
});

/* ---------- Mobile Nav Toggle ---------- */
function initNavToggle() {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (!toggle || !links) return;

  toggle.addEventListener("click", () => {
    toggle.classList.toggle("open");
    links.classList.toggle("mobile-open");
  });

  links.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => {
      toggle.classList.remove("open");
      links.classList.remove("mobile-open");
    })
  );
}

/* ---------- Dark Mode Toggle (persisted in memory for the session) ---------- */
let currentTheme = "light";

function initThemeToggle() {
  const btn = document.querySelector(".theme-toggle");
  if (!btn) return;

  // Respect OS preference on first load
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
    currentTheme = "dark";
  }
  applyTheme();

  btn.addEventListener("click", () => {
    currentTheme = currentTheme === "dark" ? "light" : "dark";
    applyTheme();
  });
}

function applyTheme() {
  document.documentElement.setAttribute("data-theme", currentTheme);
  const btn = document.querySelector(".theme-toggle");
  if (btn) {
    btn.innerHTML =
      currentTheme === "dark"
        ? `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4.5"/><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></svg>`
        : `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.5A8.5 8.5 0 1111.5 3 7 7 0 0021 12.5z"/></svg>`;
  }
}

/* ---------- Scroll Reveal Animation ---------- */
function initScrollReveal() {
  const items = document.querySelectorAll(".reveal");
  if (!items.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("in-view");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  items.forEach((item) => observer.observe(item));
}

/* ---------- Sticky Header Shrink on Scroll ---------- */
function initHeaderShrink() {
  const nav = document.querySelector(".navbar");
  if (!nav) return;
  window.addEventListener("scroll", () => {
    if (window.scrollY > 20) {
      nav.style.boxShadow = "0 6px 20px -12px rgba(11,31,58,0.25)";
    } else {
      nav.style.boxShadow = "none";
    }
  });
}

/* ---------- Testimonial Slider ---------- */
function initTestimonialSlider() {
  const track = document.querySelector(".slider-track");
  const dotsWrap = document.querySelector(".slider-dots");
  if (!track || !dotsWrap) return;

  const slides = track.children;
  let index = 0;
  let timer = null;

  Array.from(slides).forEach((_, i) => {
    const dot = document.createElement("button");
    if (i === 0) dot.classList.add("active");
    dot.addEventListener("click", () => goTo(i));
    dotsWrap.appendChild(dot);
  });

  const dots = dotsWrap.children;

  function goTo(i) {
    index = (i + slides.length) % slides.length;
    track.style.transform = `translateX(-${index * 100}%)`;
    Array.from(dots).forEach((d, di) => d.classList.toggle("active", di === index));
  }

  document.querySelector(".slider-arrow.next")?.addEventListener("click", () => {
    goTo(index + 1);
    resetTimer();
  });
  document.querySelector(".slider-arrow.prev")?.addEventListener("click", () => {
    goTo(index - 1);
    resetTimer();
  });

  function resetTimer() {
    clearInterval(timer);
    timer = setInterval(() => goTo(index + 1), 5000);
  }
  resetTimer();
}

/* ---------- FAQ Accordion ---------- */
function initAccordion() {
  const items = document.querySelectorAll(".accordion-item");
  items.forEach((item) => {
    const header = item.querySelector(".accordion-header");
    const panel = item.querySelector(".accordion-panel");
    header.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      items.forEach((i) => {
        i.classList.remove("open");
        i.querySelector(".accordion-panel").style.maxHeight = null;
      });
      if (!isOpen) {
        item.classList.add("open");
        panel.style.maxHeight = panel.scrollHeight + "px";
      }
    });
  });
}

/* ---------- Contact Form Validation ---------- */
function initContactForm() {
  const form = document.querySelector("#contactForm");
  if (!form) return;

  const fields = {
    name: { el: form.querySelector("#name"), rule: (v) => v.trim().length >= 3, msg: "Please enter at least 3 characters." },
    email: {
      el: form.querySelector("#email"),
      rule: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()),
      msg: "Please enter a valid email address.",
    },
    phone: {
      el: form.querySelector("#phone"),
      rule: (v) => v.trim() === "" || /^[0-9+\-\s]{10,15}$/.test(v.trim()),
      msg: "Please enter a valid phone number.",
    },
    subject: { el: form.querySelector("#subject"), rule: (v) => v.trim().length >= 3, msg: "Please enter a subject." },
    message: { el: form.querySelector("#message"), rule: (v) => v.trim().length >= 10, msg: "Message should be at least 10 characters." },
  };

  Object.values(fields).forEach(({ el }) => {
    if (!el) return;
    el.addEventListener("input", () => validateField(el.id));
    el.addEventListener("blur", () => validateField(el.id));
  });

  function validateField(id) {
    const field = fields[id];
    if (!field || !field.el) return true;
    const group = field.el.closest(".form-group");
    const valid = field.rule(field.el.value);
    group.classList.toggle("invalid", !valid);
    group.classList.toggle("valid", valid);
    const errorEl = group.querySelector(".error-msg");
    if (errorEl) errorEl.textContent = field.msg;
    return valid;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    let allValid = true;
    Object.keys(fields).forEach((id) => {
      if (!validateField(id)) allValid = false;
    });

    const statusEl = form.querySelector(".form-status");

    if (allValid) {
      statusEl.textContent = "✓ Thanks! Your message has been received. We'll get back to you within one business day.";
      statusEl.classList.remove("error");
      statusEl.classList.add("show", "success");
      form.reset();
      Object.values(fields).forEach(({ el }) => {
        if (el) el.closest(".form-group").classList.remove("valid", "invalid");
      });
    } else {
      statusEl.textContent = "✗ Please fix the highlighted fields before submitting.";
      statusEl.classList.remove("success");
      statusEl.classList.add("show", "error");
    }

    setTimeout(() => statusEl.classList.remove("show"), 6000);
  });
}

/* ---------- Hero Terminal Typing Animation ---------- */
function initTerminalTyping() {
  const body = document.querySelector(".terminal-body");
  if (!body) return;

  const lines = [
    { html: '<span class="prompt">$</span> npm create technova-app' },
    { html: '<span class="comment">// scaffolding responsive site...</span>' },
    { html: '<span class="out">✔ HTML, CSS, JavaScript ready</span>' },
    { html: '<span class="out">✔ Bootstrap components linked</span>' },
    { html: '<span class="out">✔ Dark mode + animations enabled</span>' },
    { html: '<span class="prompt">$</span> deploy --target=github-pages' },
    { html: '<span class="out">🚀 Live in 12s</span>' },
  ];

  body.innerHTML = "";
  lines.forEach((line, i) => {
    const div = document.createElement("div");
    div.className = "line";
    div.style.animationDelay = `${i * 0.45 + 0.2}s`;
    div.innerHTML = line.html;
    body.appendChild(div);
  });
  const cursor = document.createElement("span");
  cursor.className = "cursor";
  body.appendChild(cursor);
}
